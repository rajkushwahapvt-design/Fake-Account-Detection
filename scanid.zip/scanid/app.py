from flask import Flask, request, jsonify, render_template
import joblib, pandas as pd
from train import FEATURES

app = Flask(__name__)
model = joblib.load("model.pkl")

def digit_ratio(text):
    return sum(c.isdigit() for c in text) / len(text) if text else 0

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    d = request.get_json()
    username = d.get("username", "").strip()
    fullname = d.get("fullname", "").strip()
    row = {
        "profile_pic": int(d.get("profile_pic", 0)),
        "username_digit_ratio": digit_ratio(username),
        "fullname_words": len(fullname.split()),
        "fullname_digit_ratio": digit_ratio(fullname),
        "name_equals_username": int(fullname.lower().replace(" ", "") == username.lower()),
        "bio_length": len(d.get("bio", "")),
        "external_url": int(d.get("external_url", 0)),
        "private": int(d.get("private", 0)),
        "posts": int(d.get("posts", 0) or 0),
        "followers": int(d.get("followers", 0) or 0),
        "following": int(d.get("following", 0) or 0),
    }
    prob_fake = model.predict_proba(pd.DataFrame([row])[FEATURES])[0][1]
    return jsonify({"fake_probability": round(prob_fake * 100, 1),
                    "label": "Fake" if prob_fake >= 0.5 else "Real"})

if __name__ == "__main__":
    app.run(debug=True)
