const $ = (id) => document.getElementById(id);

const examples = {
  real: { username: "rahul.sharma", fullname: "Rahul Sharma", bio: "CS student, Lucknow | coder",
          posts: 120, followers: 640, following: 410, profile_pic: true, external_url: false, private: false },
  fake: { username: "user83921744", fullname: "", bio: "",
          posts: 0, followers: 4, following: 3200, profile_pic: false, external_url: true, private: false },
};

function fillExample(type) {
  const e = examples[type];
  for (const key in e) {
    const el = $(key);
    if (el.type === "checkbox") el.checked = e[key];
    else el.value = e[key];
  }
}

async function checkAccount() {
  const data = {
    username: $("username").value,
    fullname: $("fullname").value,
    bio: $("bio").value,
    posts: $("posts").value,
    followers: $("followers").value,
    following: $("following").value,
    profile_pic: $("profile_pic").checked ? 1 : 0,
    external_url: $("external_url").checked ? 1 : 0,
    private: $("private").checked ? 1 : 0,
  };

  const btn = $("checkBtn");
  btn.textContent = "Checking...";
  btn.disabled = true;

  try {
    const res = await fetch("/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const out = await res.json();
    showResult(out);
  } catch (err) {
    alert("Server se connect nahi hua. Flask chal raha hai?");
  }

  btn.textContent = "Check Account";
  btn.disabled = false;
}

function showResult(out) {
  const box = $("result");
  const isFake = out.label === "Fake";
  box.className = isFake ? "fake" : "real";
  $("verdict").textContent = isFake ? "⚠️ Likely FAKE" : "✅ Looks REAL";
  $("percent").textContent = "Fake probability: " + out.fake_probability + "%";
  $("barFill").style.width = out.fake_probability + "%";
}
